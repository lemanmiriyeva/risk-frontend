export const metadata = {
    title: 'MİS-Şifrəni təyin et',
    description:
        'Şifrəni təyin et',
};
export default function layout({children}) {
    return (
        <>{children}</>
    )
}